#include<bits/stdc++.h>

using namespace std;

struct node
{
    int val;
    int ind;
};

bool myf(node i,node j)
{
    return i.val<j.val;
}

int main()
{
    vector<int> v;
    v.push_back();
    v.pop_back();
    v.clear();
    v.erase();
    v.begin();
    v.end();
    v.back();
    v.size();
    v.resize();
    v[i]

    string s;
    s.begin();
    s.end();
    s.append();
    s.clear();
    s.compare();
    s.erase();
    s.find();
    s.length();


    pair<int,int> p;
    p.first;
    p.second;

    map<int,string> m;


    set<int> se;
    se.begin();
    se.end();
    se.count();
    se.empty();
    se.find();
    se.insert();
    se.erase();

    vector<int>::iterator it;

    node n[100];
    sort(n,n+100,myf);
   return 0;
}

